"""KRT Terminal — local website. KRT.bat double-click செய்தால் இது ஓடும்.
உங்கள் PC-ல் மட்டும் (127.0.0.1) — வெளியே யாருக்கும் தெரியாது."""
import base64, json, os, re, threading, time, traceback, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import pandas as pd

from krt.config import ROOT
from krt.runner import run_scan, now_ist, market_open, angel_configured
from krt.chartink import CLAUSE_FILE, saved_clauses
from krt.config import load_settings

HOSTED = bool(os.getenv("RENDER") or os.getenv("HOSTED"))
PORT = int(os.getenv("PORT", "8765"))
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
STATE = {"scanning": False, "result": None, "error": None, "last_run": None, "slot": None,
         "full": None, "full_error": None, "full_running": False, "full_last": None, "progress": "", "fslot": None}
ANGEL = None
LOCK = threading.Lock()
API_LOCK = threading.Lock()  # Chartink scan + full scan ஒரே நேரத்தில் Angel API-ஐ அடிக்கக்கூடாது (rate limit)


def _json(o):
    return json.dumps(o, default=str, ensure_ascii=False)


def do_scan(at=None):
    with LOCK:
        if STATE["scanning"]:
            return False
        STATE["scanning"] = True
    try:
        if not angel_configured():
            raise RuntimeError("Angel One connect ஆகவில்லை — demo data காட்டப்படாது")
        with API_LOCK:
            res = run_scan("angel", at or None)
        STATE.update(result=res, error=None)
    except Exception as e:
        traceback.print_exc()
        STATE["error"] = str(e)
    finally:
        STATE["last_run"] = str(now_ist())
        STATE["scanning"] = False
    return True


def do_full():
    global ANGEL
    with LOCK:
        if STATE["full_running"]:
            return False
        STATE["full_running"] = True
    try:
        if not angel_configured():
            raise RuntimeError("Angel One connect ஆகவில்லை — Render Environment-ல் ANGEL_API_KEY, ANGEL_CLIENT_ID, ANGEL_MPIN, ANGEL_TOTP_SECRET வேண்டும்")
        from krt.angel_api import Angel
        from krt.fullscan import run_full
        ANGEL = ANGEL or Angel()
        with API_LOCK:
            res = run_full(ANGEL, lambda m: STATE.update(progress=m))
        old = STATE.get("full") or {}
        if old.get("power") and not res.get("power"):
            res["power"] = old["power"]          # POWER OI தனி loop — deep scan அழிக்கக்கூடாது
            try:
                from krt.fullscan import compute_all_rounder
                compute_all_rounder(res)
            except Exception:
                pass
        STATE.update(full=res, full_error=None)
        try:
            from krt.store import SNAP
            from krt.fullscan import export_cache
            snap = dict(res)
            snap["tracking"] = {k: v for k, v in (res.get("tracking") or {}).items() if k != "history"}
            SNAP.load()
            SNAP.data = {"result": snap, "cache": export_cache(), "saved": str(now_ist())}
            SNAP.dirty = True
            SNAP.save()
        except Exception:
            traceback.print_exc()
    except Exception as e:
        traceback.print_exc()
        STATE["full_error"] = str(e)
    finally:
        STATE.update(full_last=str(now_ist()), full_running=False, progress="")
    return True


def ticker():
    """Market நேரத்தில் 30 sec-க்கு ஒருமுறை live price / option LTP / T1-SL update (deep scan நடந்தாலும்)."""
    global ANGEL
    while True:
        time.sleep(30)
        try:
            if not (market_open(now_ist()) and angel_configured() and STATE.get("full")):
                continue
            from krt.angel_api import Angel
            from krt.fullscan import fast_tick
            ANGEL = ANGEL or Angel()
            STATE["full"] = fast_tick(ANGEL, STATE["full"])
        except Exception:
            traceback.print_exc()


NEWS = {"items": [], "err": None, "t": None}
GU = {"data": None, "err": None}


def gu_loop():
    """GAMMA-UNWIND: market நேரத்தில் 5 நிமிடத்துக்கு ஒருமுறை (candle முடிந்த 2 நிமிடம் கழித்து)."""
    global ANGEL
    done = None
    while True:
        time.sleep(20)
        try:
            t = now_ist()
            slot = t.floor("5min")
            if not (market_open(t) and angel_configured()) or t.minute % 5 != 2 or done == slot:
                continue
            if t.hour * 60 + t.minute < 9 * 60 + 20:
                continue
            done = slot
            from krt.angel_api import Angel
            from krt.fullscan import C
            from krt.instruments import load as load_inst, contracts
            from krt import gamma_unwind as G
            from krt.calls import update_calls
            if not C.get("bars"):
                GU["err"] = "Daily data இன்னும் load ஆகவில்லை (deep scan முடிய காத்திருக்கிறது)"
                continue
            ANGEL = ANGEL or Angel()
            inst = load_inst(ROOT / "data" / "cache")
            ltp_of = {}
            mins = t.hour * 60 + t.minute
            need_sel = (mins >= 13 * 60 + 15 and "13:15" not in G.ST["sel"]) or ("09:20" not in G.ST["sel"] and "13:15" not in G.ST["sel"]) or G.ST["day"] != str(t.date())
            if need_sel:
                names = [n for n in inst["fno"] if n in inst["eq"]]
                qs = ANGEL.quotes({"NSE": [inst["eq"][n] for n in names]})
                ltp_of = {n: float((qs.get(inst["eq"][n]) or {}).get("ltp") or 0) for n in names}
            regime = {"trend": (STATE.get("full") or {}).get("trend")}
            from krt.store import STORE
            sl_today = sum(1 for c_ in STORE.load()["calls"].values()
                           if c_["kind"].startswith("GU-") and c_["date"] == str(t.date()) and c_["status"] == "SL HIT")
            snap = G.run(ANGEL, inst, C, ltp_of, t, regime, sl_today)
            entries = [s_ for s_ in snap["signals"] if s_["tier"] == "PRO ENTRY"]
            update_calls(ANGEL, pd.Timestamp(t.date()), t, True, [], [], [], [], {"10": [], "5": []}, add=False, gu=entries)
            GU.update(data=snap, err=None)
            C["_gu_snap"] = snap
        except Exception as e:
            traceback.print_exc()
            GU["err"] = str(e)


def news_loop():
    """10 நிமிடத்துக்கு ஒருமுறை Google News RSS — market + setup stocks."""
    from krt.news import refresh
    while True:
        try:
            f = STATE.get("full") or {}
            syms = []
            for key in ("best", "patterns", "ce", "pe"):
                for r in f.get(key) or []:
                    if r["symbol"] not in syms:
                        syms.append(r["symbol"])
            try:
                from krt.instruments import _MEM
                fno = (_MEM.get("data") or {}).get("fno") or []
            except Exception:
                fno = []
            c = refresh(syms, fno)
            NEWS.update(items=c["items"], err=c["err"], t=str(now_ist()))
        except Exception as e:
            NEWS["err"] = str(e)
        time.sleep(60)


def power_loop():
    """🎯 POWER OI: ஒவ்வொரு 5-min candle முடிந்த 3 நிமிடத்தில் (9:33, 9:38…)."""
    global ANGEL
    done = None
    while True:
        time.sleep(15)
        try:
            t = now_ist()
            slot = t.floor("5min")
            if not (market_open(t) and angel_configured() and STATE.get("full")) or t.minute % 5 != 3 or done == slot:
                continue
            if t.hour * 60 + t.minute < 9 * 60 + 33:
                continue
            done = slot
            from krt.angel_api import Angel
            from krt.fullscan import run_power
            ANGEL = ANGEL or Angel()
            STATE["full"] = run_power(ANGEL, STATE["full"])
        except Exception:
            traceback.print_exc()


def elite_loop():
    """👑 Elite: ஒவ்வொரு 15-min candle முடிந்த 1 நிமிடத்தில் (9:31, 9:46, 10:01…) — deep scan-க்கு காத்திருக்காது."""
    global ANGEL
    done = None
    while True:
        time.sleep(15)
        try:
            t = now_ist()
            slot = t.floor("15min")
            if not (market_open(t) and angel_configured() and STATE.get("full")) or t.minute % 15 != 1 or done == slot:
                continue
            done = slot
            from krt.angel_api import Angel
            from krt.fullscan import run_elite_fast
            ANGEL = ANGEL or Angel()
            STATE["full"] = run_elite_fast(ANGEL, STATE["full"])
        except Exception:
            traceback.print_exc()


def scheduler():
    """Market நேரத்தில் ஒவ்வொரு 15-min candle முடிந்த 1 நிமிடம் கழித்து auto scan."""
    while True:
        t = now_ist()
        slot = t.floor("15min")
        if market_open(t) and t.minute % 15 == 1 and STATE["slot"] != slot and angel_configured():
            STATE["slot"] = slot
            threading.Thread(target=do_scan, daemon=True).start()
        fslot = t.floor("5min")
        if market_open(t) and t.minute % 5 == 1 and STATE["fslot"] != fslot and angel_configured():
            STATE["fslot"] = fslot
            threading.Thread(target=do_full, daemon=True).start()
        time.sleep(15)


def next_auto():
    """Full scan: market நேரத்தில் 5 நிமிடத்துக்கு ஒருமுறை (முந்தைய scan முடிந்திருந்தால்)."""
    t = now_ist()
    for i in range(1, 60 * 24 * 4):
        c = t + pd.Timedelta(minutes=i)
        if c.minute % 5 == 1 and market_open(c):
            return str(c)
    return None


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def _auth_ok(self):
        if not APP_PASSWORD:
            return True  # password set பண்ணலைன்னா login இல்லாமல் திறக்கும்
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                _, pw = base64.b64decode(h[6:]).decode("utf-8").split(":", 1)
                return pw == APP_PASSWORD
            except Exception:
                return False
        return False

    def _deny(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="KRT Terminal"')
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, "ok", "text/plain")
        if not self._auth_ok():
            return self._deny()
        if self.path in ("/", "/index.html"):
            return self._send(200, (ROOT / "web" / "index.html").read_bytes(), "text/html; charset=utf-8")
        if self.path == "/api/status":
            cfg = load_settings().get("chartink", {})
            cl = saved_clauses()
            return self._send(200, _json({
                **{k: STATE[k] for k in ("scanning", "result", "error", "last_run", "full", "full_error",
                                         "full_running", "full_last", "progress")},
                "news": NEWS, "gu": GU, "telegram": __import__("krt.telegram", fromlist=["enabled"]).enabled(),
                "configured": angel_configured(), "hosted": HOSTED, "now": str(now_ist()),
                "market_open": market_open(now_ist()), "next_auto": next_auto(),
                "chartink": {"ce_url": cfg.get("ce_url"), "pe_url": cfg.get("pe_url"),
                             "ce_saved": bool(cl.get("ce")), "pe_saved": bool(cl.get("pe"))},
            }))
        self._send(404, _json({"error": "not found"}))

    def do_POST(self):
        if not self._auth_ok():
            return self._deny()
        try:
            d = self._body()
        except Exception:
            return self._send(400, _json({"ok": False, "msg": "தவறான request"}))

        if self.path == "/api/full":
            if STATE["full_running"]:
                return self._send(200, _json({"ok": False, "msg": "Full scan ஏற்கனவே ஓடுகிறது"}))
            threading.Thread(target=do_full, daemon=True).start()
            return self._send(200, _json({"ok": True, "msg": ""}))

        if self.path == "/api/scan":
            started = do_scan_async(d.get("at"))
            return self._send(200, _json({"ok": started, "msg": "" if started else "1 நிமிடம் கழித்து மறுபடி try பண்ணுங்க"}))

        if self.path == "/api/setup":
            if HOSTED:
                return self._send(200, _json({"ok": False, "msg": "Website-ல் Angel One details Render → Environment-ல் மட்டும் வைக்கவும்"}))
            import pyotp
            api, client = d.get("api_key", "").strip(), d.get("client_id", "").strip().upper()
            mpin, totp = d.get("mpin", "").strip(), d.get("totp", "").strip().replace(" ", "").upper()
            if not api or not client:
                return self._send(200, _json({"ok": False, "msg": "API key, Client ID இரண்டும் வேண்டும்"}))
            if not re.fullmatch(r"\d{4}", mpin):
                return self._send(200, _json({"ok": False, "msg": "MPIN 4 எண்கள் மட்டும்"}))
            try:
                pyotp.TOTP(totp).now()
                assert len(totp) >= 16
            except Exception:
                return self._send(200, _json({"ok": False, "msg": "TOTP secret தவறு — QR கீழே உள்ள text code-ஐ copy பண்ணுங்க"}))
            (ROOT / ".env").write_text(
                f"BROKER=angel\nANGEL_API_KEY={api}\nANGEL_CLIENT_ID={client}\nANGEL_MPIN={mpin}\nANGEL_TOTP_SECRET={totp}\n",
                encoding="utf-8")
            try:
                from dotenv import load_dotenv
                load_dotenv(ROOT / ".env", override=True)
                from krt.data.angel_provider import angel_login
                _, s = angel_login()
                name = (s.get("data") or {}).get("name", "")
                return self._send(200, _json({"ok": True, "msg": f"Angel One login OK — {name}"}))
            except Exception as e:
                return self._send(200, _json({"ok": False, "msg": f"Save ஆனது, ஆனால் login fail: {e}"}))

        if self.path == "/api/clause":
            side, clause = d.get("side"), (d.get("clause") or "").strip()
            if side not in ("ce", "pe"):
                return self._send(200, _json({"ok": False, "msg": "side தவறு"}))
            data = saved_clauses()
            if not clause:
                data.pop(side, None)
                msg = f"{side.upper()} clause நீக்கப்பட்டது — auto mode"
            elif clause.startswith("(") and "{" in clause:
                data[side] = clause
                msg = f"{side.upper()} clause saved ({len(clause)} characters)"
            else:
                return self._send(200, _json({"ok": False, "msg": "இது scan clause இல்லை — '( {' என்று தொடங்க வேண்டும்"}))
            CLAUSE_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            return self._send(200, _json({"ok": True, "msg": msg}))

        self._send(404, _json({"error": "not found"}))


LAST_START = [0.0]


def do_scan_async(at=None):
    # 60 second-க்குள் மறுபடி scan வேண்டாம் (Angel One rate limit பாதுகாப்பு)
    if STATE["scanning"] or time.time() - LAST_START[0] < 60:
        return False
    LAST_START[0] = time.time()
    threading.Thread(target=do_scan, args=(at,), daemon=True).start()
    return True


def restore():
    """Restart ஆனதும் கடைசி scan result-ஐ உடனே காட்டு + daily cache load."""
    try:
        from krt.store import SNAP
        from krt.fullscan import import_cache
        d = SNAP.load()
        if d.get("result"):
            r = d["result"]
            r["restored"] = d.get("saved")
            STATE.update(full=r, full_last=d.get("saved"))
        import_cache(d.get("cache"))
        from krt.store import BARS
        from krt.fullscan import import_bars
        ok = import_bars(BARS.load())
        print(" Snapshot restored:", d.get("saved"), "· bars:", ok, flush=True)
    except Exception:
        traceback.print_exc()


if __name__ == "__main__":
    restore()
    threading.Thread(target=scheduler, daemon=True).start()
    threading.Thread(target=ticker, daemon=True).start()
    threading.Thread(target=news_loop, daemon=True).start()
    threading.Thread(target=gu_loop, daemon=True).start()
    threading.Thread(target=elite_loop, daemon=True).start()
    threading.Thread(target=power_loop, daemon=True).start()
    if angel_configured():  # start ஆனதும் ஒரு full scan
        threading.Thread(target=do_full, daemon=True).start()
    host = "0.0.0.0" if HOSTED else "127.0.0.1"
    url = f"http://127.0.0.1:{PORT}"
    srv = ThreadingHTTPServer((host, PORT), H)
    print(f"\n KRT Terminal ஓடுகிறது → {url if not HOSTED else 'hosted, port ' + str(PORT)}", flush=True)
    if not HOSTED:
        print(" இந்த window-ஐ close பண்ணா website நின்றுவிடும். Minimize பண்ணி வைங்க.\n")
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    srv.serve_forever()
